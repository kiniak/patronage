# Hamburger menu

Hamburger menu with CSS animations and pure JavaScript

<img src="images/hamburger-menu-screenshot.gif" alt="" style="margin: 0 auto; max-width: 100%;" />

View codepen: <a href="https://codepen.io/mranenko/full/wevamj">
https://codepen.io/mranenko/full/wevamj</a>
